FUTURE COACHING CLASSES - GITHUB FILES

Main file:
index.html

Images:
teacher.png = your coaching/teacher photo
papa.jpg = Pandit Ganesh Kumar Tiwari memorial photo
scanner.png = your UPI QR scanner

Notes:
Put your real PDF files inside the notes folder using these names:
class10-maths.pdf
science.pdf
social-science.pdf
important-questions.pdf

IMPORTANT:
The PDF files included here are only placeholders. Replace them with your real PDFs.
You can later change YouTube links, contact number, address and class timings directly in index.html.
